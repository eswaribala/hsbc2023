package com.hsbc.ecommerceappv1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ecommerceappv1Application {

	public static void main(String[] args) {
		SpringApplication.run(Ecommerceappv1Application.class, args);
	}

}
