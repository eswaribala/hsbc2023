package com.hsbc.ecommerceappv1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ecommerceappv1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
